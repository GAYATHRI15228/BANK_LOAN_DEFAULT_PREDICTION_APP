package com.example.loan_default;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;



import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;

public class LoanApplicationActivity extends AppCompatActivity {

    private EditText loanAmountEditText;
    private EditText loanPurposeEditText;
    private EditText termsEditText;
    private EditText ficoScoreEditText;
    private EditText annualIncomeEditText;
    private EditText mortgageEditText;
    private Spinner houseLabelSpinner;
    private Spinner employmentSpinner;
    private Button predictButton;
    private ListView formListView;

    private String selectedHouseLabel;
    private String selectedEmployment;

    // Notification channel constants
    private static final String CHANNEL_ID = "loan_channel";
    private static final String CHANNEL_NAME = "Loan Notification";
    private static final String CHANNEL_DESCRIPTION = "Notification for Loan Status";
    private static final int NOTIFICATION_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_application);

        // Initialize views
        loanAmountEditText = findViewById(R.id.loanAmountEditText);
        loanPurposeEditText = findViewById(R.id.loanPurposeEditText);
        termsEditText = findViewById(R.id.termsEditText);
        ficoScoreEditText = findViewById(R.id.ficoScoreEditText);
        annualIncomeEditText = findViewById(R.id.annualIncomeEditText);
        mortgageEditText = findViewById(R.id.mortgageEditText);
        houseLabelSpinner = findViewById(R.id.houseLabelSpinner);
        employmentSpinner = findViewById(R.id.employmentSpinner);
        predictButton = findViewById(R.id.predictButton);
        formListView = findViewById(R.id.formListView);

        // Populate spinner data
        List<String> houseLabels = new ArrayList<>();
        houseLabels.add("Rent");
        houseLabels.add("Own");
        houseLabels.add("Mortgages");

        ArrayAdapter<String> houseLabelAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, houseLabels);
        houseLabelAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        houseLabelSpinner.setAdapter(houseLabelAdapter);

        List<String> employmentList = new ArrayList<>();
        employmentList.add("Employed");
        employmentList.add("Unemployed");

        ArrayAdapter<String> employmentAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, employmentList);
        employmentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        employmentSpinner.setAdapter(employmentAdapter);

        // Set click listener for predictButton
        predictButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Validate form details
                if (!validateFormDetails()) {
                    Toast.makeText(LoanApplicationActivity.this, "Please fill in all the details", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Get the input values
                double loanAmount = Double.parseDouble(loanAmountEditText.getText().toString());
                String loanPurpose = loanPurposeEditText.getText().toString();
                int terms = Integer.parseInt(termsEditText.getText().toString());
                int ficoScore = Integer.parseInt(ficoScoreEditText.getText().toString());
                int annualIncome = Integer.parseInt(annualIncomeEditText.getText().toString());
                double mortgage = Double.parseDouble(mortgageEditText.getText().toString());

                // Check conditions
                boolean isDefault = false;

                if (annualIncome < loanAmount ||
                        ficoScore < 630 ||
                        mortgage > 6 ||
                        (selectedEmployment.equals("Unemployed") && mortgage > 3) ||
                        (selectedEmployment.equals("Unemployed") && annualIncome < loanAmount) ||
                        (selectedHouseLabel.equals("Mortgage") && annualIncome < loanAmount) ||
                        (selectedEmployment.equals("Unemployed") && selectedHouseLabel.equals("Rent")) ||
                        (selectedEmployment.equals("Employed") && annualIncome < 25000)||
                        (selectedHouseLabel.equals("Mortgage") && selectedEmployment.equals("Unemployed"))) {
                    isDefault = true;
                }

                // Create a list of form entries
                List<String> formEntries = new ArrayList<>();

                // Check if default conditions are satisfied
                if (isDefault) {
                    // Add default entry
                    showNotification("Your Loan Application is Denied");
                } else {
                    // Add regular form entries
                    formEntries.add("NOT A DEFAULT : Loan Granted");
                    showNotification("Your Loan Application is Granted");
                }

                // Check if any form entries are present
                if (formEntries.isEmpty()) {
                    formEntries.add("DEFAULT : Loan Denied");
                }

                // Create an ArrayAdapter to display form entries in ListView
                ArrayAdapter<String> formEntriesAdapter = new ArrayAdapter<>(LoanApplicationActivity.this, android.R.layout.simple_list_item_1, formEntries);
                formListView.setAdapter(formEntriesAdapter);
            }
        });

        // Set listener for houseLabelSpinner
        houseLabelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                selectedHouseLabel = houseLabels.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Do nothing
            }
        });

        // Set listener for employmentSpinner
        employmentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                selectedEmployment = employmentList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Do nothing
            }
        });
    }

    private boolean validateFormDetails() {
        String loanAmount = loanAmountEditText.getText().toString();
        String loanPurpose = loanPurposeEditText.getText().toString();
        String terms = termsEditText.getText().toString();
        String ficoScore = ficoScoreEditText.getText().toString();
        String annualIncome = annualIncomeEditText.getText().toString();
        String mortgage = mortgageEditText.getText().toString();

        return !loanAmount.isEmpty() && !loanPurpose.isEmpty() && !terms.isEmpty()
                && !ficoScore.isEmpty() && !annualIncome.isEmpty() && !mortgage.isEmpty();
    }

    // Method to display notification message in the top mobile notification bar
    private void showNotification(String message) {
        // Create a notification channel (required for Android Oreo and above)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(CHANNEL_DESCRIPTION);
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.notification)
                .setContentTitle("Loan Application Status")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);
// Show the notification
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(NOTIFICATION_ID, builder.build());

        // Show the notification

    }
}
